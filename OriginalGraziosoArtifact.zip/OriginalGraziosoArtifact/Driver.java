import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    // Instance variables (if needed)
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        Character menuValue = null;

        initializeDogList();
        initializeMonkeyList();

        // Add a loop that displays the menu, accepts the users input
        // and takes the appropriate action.
	// For the project submission you must also include input validation
        // and appropriate feedback to the user.
        // Hint: create a Scanner and pass it to the necessary
        // methods 
	// Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
        do {
        	try {
        	    displayMenu();
        	    menuValue = scnr.nextLine().charAt(0);
        	    if (menuValue =='1') {
        		    // Intake new dog
        		    intakeNewDog(scnr);
        	    }
        	    else if (menuValue == '2') {
        		    // Intake new monkey
        		    intakeNewMonkey(scnr);
        	    }
        	    else if (menuValue == '3') {
        		    //Reserve an animal
        		    reserveAnimal(scnr);
        	    }
        	    else if (menuValue == '4') {
        		    //print list of all dogs
        		    printAnimals('4');
        	    }
        	    else if (menuValue == '5') {
        		    //print list of all monkeys
        		    printAnimals('5');
        	    }
        	    else if (menuValue == '6') {
        		    //print list of all animals not reserved
        		    printAnimals('6');
        	    }
        	    else if (menuValue == 'q') {
        	    	continue;
        	    }
        	    else {
        	    	throw new Exception("Invalid Input");
        	    }
        	}
        	catch (Exception excpt) {
        		System.out.println(excpt.getMessage());
        	}
        } while(menuValue != 'q');

    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {

    }


    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
        }

        // Add the code to instantiate a new dog and add it to the appropriate list
        Dog dog = new Dog(name, "N/a", "N/a", "unknown", "N/a", "00-00-0000", "unknown", "intake", false, "N/a");
        dogList.add(dog);
        System.out.println("What is the dog's breed?");
        dog.setBreed(scanner.nextLine());
        System.out.println("What is the dog's gender?");
        dog.setGender(scanner.nextLine());
        System.out.println("How old is the dog?");
        dog.setAge(scanner.nextLine());
        System.out.println("How much does the dog weigh?");
        dog.setWeight(scanner.nextLine());
        System.out.println("Date the dog was aquired?(month-date-year)");
        dog.setAcquisitionDate(scanner.nextLine());
        System.out.println("Aquired country?");
        dog.setAcquisitionLocation(scanner.nextLine());
        System.out.println("Dogs current training status?");
        dog.setTrainingStatus(scanner.nextLine());
        System.out.println("What country is the dog in service in?");
        dog.setInServiceCountry(scanner.nextLine());
        System.out.println("Is the dog currently reserved?(true or false)");
        dog.setReserved(scanner.nextBoolean());
        
    }


        // Complete intakeNewMonkey
	//Instantiate and add the new monkey to the appropriate list
        // For the project submission you must also  validate the input
	// to make sure the monkey doesn't already exist and the species type is allowed
        public static void intakeNewMonkey(Scanner scanner) {
        	boolean valid = false;
        	String monkeySpecies = null;
            // System.out.println("The method intakeNewMonkey needs to be implemented");
            System.out.println("What is the monkey's name?");
            String name = scanner.nextLine();
            for(Monkey monkey: monkeyList) {
                if(monkey.getName().equalsIgnoreCase(name)) {
                    System.out.println("\n\nThis monkey is already in our system\n\n");
                    return; //returns to menu
                }
            }
            Monkey monkey = new Monkey(name, "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", false, "n/a");
            monkeyList.add(monkey);
            do {
            	try {
            		System.out.println("What is the monkey's species?");
            	    monkeySpecies = scanner.nextLine();
            	    if (monkeySpecies.equalsIgnoreCase("capuchin")||monkeySpecies.equalsIgnoreCase("guenon")||monkeySpecies.equalsIgnoreCase("macaque")||monkeySpecies.equalsIgnoreCase("marmoset")||monkeySpecies.equalsIgnoreCase("squirrel monkey")||monkeySpecies.equalsIgnoreCase("tamarin")) {
            		    valid = true;
            	    }
            	    else {
            		    throw new Exception("Species not allowed");
            	    }
            	}
            	catch (Exception e){
            		System.out.println(e.getMessage());
            	}
            } while (!valid);
            monkey.setSpecies(monkeySpecies);
            System.out.println("What is the monkeys's gender?");
            monkey.setGender(scanner.nextLine());
            System.out.println("How old is the monkey?");
            monkey.setAge(scanner.nextLine());
            System.out.println("How much does the monkey weigh?");
            monkey.setWeight(scanner.nextLine());
            System.out.println("How long is the monkey's tail?");
            monkey.setTailLength(scanner.nextLine());
            System.out.println("How tall is the monkey?");
            monkey.setHeight(scanner.nextLine());
            System.out.println("What is the monkey's body length?");
            monkey.setBodyLength(scanner.nextLine());
            System.out.println("Date the monkey was aquired?(month-date-year)");
            monkey.setAcquisitionDate(scanner.nextLine());
            System.out.println("Aquired country?");
            monkey.setAcquisitionLocation(scanner.nextLine());
            System.out.println("Monkey's current training status?");
            monkey.setTrainingStatus(scanner.nextLine());
            System.out.println("What country is the monkey in service in?");
            monkey.setInServiceCountry(scanner.nextLine());
            System.out.println("Is the monkey currently reserved?(true or false)");
            monkey.setReserved(scanner.nextBoolean());
            
        }

        // Complete reserveAnimal
        // You will need to find the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
        	String animalType = null;
        	String countryServiced = null;
        	boolean valid = false;
            // System.out.println("The method reserveAnimal needs to be implemented");
            System.out.println("What is your desired animal type?(dog or monkey)");
            do {
            	try {
            		animalType = scanner.nextLine();
            		if (animalType.equalsIgnoreCase("dog")||animalType.equalsIgnoreCase("monkey")) {
            			valid = true;
            		}
            		else {
            			throw new Exception("Not a valid type");
            		}
            	}
            	catch (Exception c) {
            		System.out.println(c.getMessage());
            	}
            }while(!valid);
            System.out.println("What country do you require services in?");
            countryServiced = scanner.nextLine();
            if (animalType.equalsIgnoreCase("dog")) {
            	for (Dog dog: dogList) {
            		if (dog.getInServiceLocation().equalsIgnoreCase(countryServiced) && dog.getReserved() == false) {
            			// print matching dog
            			System.out.print(dog.getName());
            			dog.setReserved(true);
            			valid = false;
            			break;
            		}
            	}
            	
            }
            if (animalType.equalsIgnoreCase("monkey")) {
            	for (Monkey monkey: monkeyList) {
            		if (monkey.getInServiceLocation().equalsIgnoreCase(countryServiced) && monkey.getReserved() == false) {
            			// print matching monkey
            			System.out.print(monkey.getName());
            			monkey.setReserved(true);
            			valid = false;
            			break;
            		}
            	}
            }
            if (valid) {
        		System.out.println("There are no animals that meet your requirements.");
        	}
        }

        // Complete printAnimals
        // Include the animal name, status, acquisition country and if the animal is reserved.
	// Remember that this method connects to three different menu items.
        // The printAnimals() method has three different outputs
        // based on the listType parameter
        // dog - prints the list of dogs
        // monkey - prints the list of monkeys
        // available - prints a combined list of all animals that are
        // fully trained ("in service") but not reserved 
	// Remember that you only have to fully implement ONE of these lists. 
	// The other lists can have a print statement saying "This option needs to be implemented".
	// To score "exemplary" you must correctly implement the "available" list.
        public static void printAnimals(Character value) {
            //System.out.println("The method printAnimals needs to be implemented");
            if (value == '4') { //print list of dogs
            	for (Dog dog: dogList) {
            		System.out.println(dog.getName() + ", " + dog.getTrainingStatus() + ", " + dog.getAcquisitionLocation() + ", Reserved: " + dog.getReserved());
            	}
            }
            else if (value =='5') { //print list of monkeys
            	for (Monkey monkey: monkeyList) {
            		System.out.println(monkey.getName() + ", " + monkey.getTrainingStatus() + ", " + monkey.getAcquisitionLocation() + ", Reserved: " + monkey.getReserved());
            	}
            }
            else if (value == '6') { //print combined list of all fully trained available animals
            	//TODO
            	System.out.println("Available dogs:");
            	for (Dog dog: dogList) {
            		if (dog.getTrainingStatus().equalsIgnoreCase("in service") && dog.getReserved() == false) {
            			System.out.println(dog.getName() + ", " + dog.getTrainingStatus() + ", " + dog.getAcquisitionLocation() + ", Reserved: " + dog.getReserved());
            		}
            	}
            	System.out.println("Available monkeys:");
            	for (Monkey monkey: monkeyList) {
            		if (monkey.getTrainingStatus().equalsIgnoreCase("in service") && monkey.getReserved() == false) {
            			System.out.println(monkey.getName() + ", " + monkey.getTrainingStatus() + ", " + monkey.getAcquisitionLocation() + ", Reserved: " + monkey.getReserved());
            		}
            	}
            }

        }
}

