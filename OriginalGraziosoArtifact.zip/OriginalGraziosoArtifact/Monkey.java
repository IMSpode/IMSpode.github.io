
public class Monkey extends RescueAnimal{
	
	// Instance variables
	private String tailLength;
	private String height;
	private String bodyLength;
	private String species;
	
	// Constructor
	public Monkey(String name, String species, String gender, String age,
		    String weight, String tailLength, String height, String bodyLength, String acquisitionDate, String acquisitionCountry,
			String trainingStatus, boolean reserved, String inServiceCountry) {
		setName(name);
        setSpecies(species);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setTailLength(tailLength);
        setHeight(height);
        setBodyLength(bodyLength);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
	}
	
	// Accessor Methods
	public String getTailLength() {
		return tailLength;
	}
	public String getHeight() {
		return height;
	}
	public String getBodyLength() {
		return bodyLength;
	}
	public String getSpecies() {
		return species;
	}
	
	// Mutator Methods
	public void setTailLength(String tailSize) {
		tailLength = tailSize;
	}
	public void setHeight(String monkeyHeight) {
		height = monkeyHeight;
	}
	public void setBodyLength(String bodySize) {
		bodyLength = bodySize;
	}
	public void setSpecies(String monkeySpecies) {
		species = monkeySpecies;
	}

}
