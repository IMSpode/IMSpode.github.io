#ifndef MONKEY_H
#define MONKEY_H
#pragma once
#include "RescueAnimal.h"
class Monkey :
    public RescueAnimal
{
private:
    string tailLength;
    string height;
    string bodyLength;
    string species;
public:
    Monkey();
    //constructor
    Monkey(string name, string species, string gender, string age, string weight,
        string tailLength, string height, string bodyLength, string acquisitionDate,
        string acquisitionCountry, string trainingStatus, bool reserved,
        string serviceCountry);

    //getter
    string getTailLength();
    string getHeight();
    string getBodyLength();
    string getSpecies();

    //setter
    void setTailLength(string tailLength);
    void setHeight(string height);
    void setBodyLength(string bodyLength);
    void setSpecies(string species);
};

#endif



