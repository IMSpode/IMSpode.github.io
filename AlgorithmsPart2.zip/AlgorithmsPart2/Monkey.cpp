#include "Monkey.h"

Monkey::Monkey(){
}
//constructor
Monkey::Monkey(string name, string species, string gender,
	string age, string weight, string tailLength, string height,
	string bodyLength, string acquisitionDate,
	string acquisitionCountry, string trainingStatus,
	bool reserve, string serviceCountry) {
	setName(name);
	setSpecies(species);
	setGender(gender);
	setAge(age);
	setWeight(weight);
	setTailLength(tailLength);
	setHeight(height);
	setBodyLength(bodyLength);
	setAcquisitionDate(acquisitionDate);
	setAcquisitionCountry(acquisitionCountry);
	setTrainingStatus(trainingStatus);
	setReserved(reserve);
	setServiceCountry(serviceCountry);
}

//getter
string Monkey::getTailLength() {
	return tailLength;
}
string Monkey::getHeight() {
	return height;
}
string Monkey::getBodyLength() {
	return bodyLength;
}
string Monkey::getSpecies() {
	return species;
}

//setter
void Monkey::setTailLength(string tailLength) {
	this->tailLength = tailLength;
}
void Monkey::setHeight(string height) {
	this->height = height;
}
void Monkey::setBodyLength(string bodyLength) {
	this->bodyLength = bodyLength;
}
void Monkey::setSpecies(string species) {
	this->species = species;
}

