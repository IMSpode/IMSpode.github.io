#ifndef RESCUEANIMAL_H
#define RESCUEANIMAL_H
#pragma once
#include <string>

using namespace std;


class RescueAnimal
{
private:
	string name;
	string gender;
	string age;
	string weight;
	string acquisitionDate;
	string acquisitionCountry;
	string trainingStatus;
	bool reserved;
	string serviceCountry;

public:
	//getters
	string getName();
	string getGender();
	string getAge();
	string getWeight();
	string getAcquisitionDate();
	string getAcquisitionCountry();
	string getTrainingStatus();
	bool getReserved();
	string getServiceCountry();

	//setters
	void setName(string name);
	void setGender(string gender);
	void setAge(string age);
	void setWeight(string weight);
	void setAcquisitionDate(string date);
	void setAcquisitionCountry(string country);
	void setTrainingStatus(string status);
	void setReserved(bool reserve);
	void setServiceCountry(string country);
};
#endif



