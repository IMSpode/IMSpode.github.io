#include <iostream>
using namespace std;

#include "RescueAnimal.h"

//getters
string RescueAnimal::getName() {
	return name;
}
string RescueAnimal::getGender() {
	return gender;
}
string RescueAnimal::getAge() {
	return age;
}
string RescueAnimal::getWeight() {
	return weight;
}
string RescueAnimal::getAcquisitionDate() {
	return acquisitionDate;
}
string RescueAnimal::getAcquisitionCountry() {
	return acquisitionCountry;
}
string RescueAnimal::getTrainingStatus() {
	return trainingStatus;
}
bool RescueAnimal::getReserved() {
	return reserved;
}
string RescueAnimal::getServiceCountry() {
	return serviceCountry;
}

//setters
void RescueAnimal::setName(string name) {
	this->name = name;
}
void RescueAnimal::setGender(string gender) {
	this->gender = gender;
}
void RescueAnimal::setAge(string age) {
	this->age = age;
}
void RescueAnimal::setWeight(string weight) {
	this->weight = weight;
}
void RescueAnimal::setAcquisitionDate(string date) {
	this->acquisitionDate = date;
}
void RescueAnimal::setAcquisitionCountry(string country) {
	this->acquisitionCountry = country;
}
void RescueAnimal::setTrainingStatus(string status) {
	this->trainingStatus = status;
}
void RescueAnimal::setReserved(bool reserve) {
	this->reserved = reserve;
}
void RescueAnimal::setServiceCountry(string country) {
	this->serviceCountry = country;
}
