//Blake Allen 2026
// Driver.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
#include "Dog.h"
#include "Monkey.h"
#include "SearchAndRescueFunctions.h"

//creates vectors to hold dogs and monkeys
vector<Dog> dogList;
vector<Monkey> monkeyList;


//Node structure
struct DogNode {
    Dog dog;
    DogNode* left;
    DogNode* right;

    DogNode() {
        left = nullptr;
        right = nullptr;
    }
    DogNode(Dog aDog) :
        DogNode() {
        dog = aDog;
    }
};

//Dog's Binary Search Tree Container class
class DogBST {
private:
    DogNode* dogRoot;
    void addNode(DogNode* dogNode, Dog dog);
    void inOrder(DogNode* dogNode);

public:
    DogBST();
    void Insert(Dog& dog);
    void InOrder();
    Dog Search(string dogServiceCountry);
};

//Default constructor
DogBST::DogBST() {
    dogRoot = nullptr;
}

//Tree traversal
void DogBST::InOrder() {
    inOrder(dogRoot);
}

//Insert dog
void DogBST::Insert(Dog& dog) {
    if (dogRoot == nullptr) {
        dogRoot = new DogNode(dog);
    }
    else {
        addNode(dogRoot, dog);
    }
}

//Search for matching dog by service country
Dog DogBST::Search(string dogServiceCountry) {
    DogNode* cur = dogRoot;
    while (cur != nullptr) {
        if (cur->dog.getServiceCountry().compare(dogServiceCountry)==0) {
            //service country matches!
            //TODO: write code to check if animal is available
            cout << "Dog country found" << endl;
        }
        else if (dogServiceCountry.compare(cur-> dog.getServiceCountry())<0) {
            cur = cur->left;
        }
        else {
            cur = cur->right;
        }
    }
    Dog dog;
    return dog;
}

//add dog to Node
void DogBST::addNode(DogNode* dogNode, Dog dog){
    if (dogNode != nullptr && dogNode->dog.getServiceCountry().compare(dog.getServiceCountry()) > 0) {
        if (dogNode->left == nullptr) {
            //this node is now left
            dogNode->left = new DogNode(dog);
            return;
        }
        //else recurse down the left node
        else {
            this->addNode(dogNode->left, dog);
        }
    }

    else {
        // if no right node
        if (dogNode->right == nullptr) {
            // this node becomes right
            dogNode->right = new DogNode(dog);
            return;
        }
        //else
        else {
            // recurse down the right node
            this->addNode(dogNode->right, dog);
        }
    }
}

//helper function to print dogs
void DogBST::inOrder(DogNode* dogNode) {
    if (dogNode != nullptr) {
        inOrder(dogNode->left);
        cout << dogNode -> dog.getName() << ", " << dogNode -> dog.getTrainingStatus() << ", " << dogNode->dog.getServiceCountry() << ", Reserved: " << dogNode->dog.getReserved() << endl;
        inOrder(dogNode->right);
    }
}

/**********************************************************/
//Node structure
struct MonkeyNode {
    Monkey monkey;
    MonkeyNode* left;
    MonkeyNode* right;

    MonkeyNode() {
        left = nullptr;
        right = nullptr;
    }
    MonkeyNode(Monkey aMonkey) :
        MonkeyNode() {
        monkey = aMonkey;
    }
};

//Monkeys's Binary Search Tree Container class
class MonkeyBST {
private:
    MonkeyNode* monkeyRoot;
    void addNode(MonkeyNode* monkeyNode, Monkey monkey);
    void inOrder(MonkeyNode* monkeyNode);

public:
    MonkeyBST();
    void Insert(Monkey& monkey);
    void InOrder();
    Monkey Search(string monkeyServiceCountry);
};

//Default constructor
MonkeyBST::MonkeyBST() {
    monkeyRoot = nullptr;
}

//Tree traversal
void MonkeyBST::InOrder() {
    inOrder(monkeyRoot);
}

//Insert monkey
void MonkeyBST::Insert(Monkey& monkey) {
    if (monkeyRoot == nullptr) {
        monkeyRoot = new MonkeyNode(monkey);
    }
    else {
        addNode(monkeyRoot, monkey);
    }
}

//Search for matching monkey by service country
Monkey MonkeyBST::Search(string monkeyServiceCountry) {
    MonkeyNode* cur = monkeyRoot;
    while (cur != nullptr) {
        if (cur->monkey.getServiceCountry().compare(monkeyServiceCountry) == 0) {
            //service country matches!
            //TODO: write code to check if animal is available
            cout << "Monkey country found" << endl;
        }
        else if (monkeyServiceCountry.compare(cur->monkey.getServiceCountry()) < 0) {
            cur = cur->left;
        }
        else {
            cur = cur->right;
        }
    }
    Monkey monkey;
    return monkey;
}

//add monkey to Node
void MonkeyBST::addNode(MonkeyNode* monkeyNode, Monkey monkey) {
    if (monkeyNode != nullptr && monkeyNode->monkey.getServiceCountry().compare(monkey.getServiceCountry()) > 0) {
        if (monkeyNode->left == nullptr) {
            //this node is now left
            monkeyNode->left = new MonkeyNode(monkey);
            return;
        }
        //else recurse down the left node
        else {
            this->addNode(monkeyNode->left, monkey);
        }
    }

    else {
        // if no right node
        if (monkeyNode->right == nullptr) {
            // this node becomes right
            monkeyNode->right = new MonkeyNode(monkey);
            return;
        }
        //else
        else {
            // recurse down the right node
            this->addNode(monkeyNode->right, monkey);
        }
    }
}

//helper function to print monkeys
void MonkeyBST::inOrder(MonkeyNode* monkeyNode) {
    if (monkeyNode != nullptr) {
        inOrder(monkeyNode->left);
        cout << monkeyNode->monkey.getName() << ", " << monkeyNode->monkey.getTrainingStatus() << ", " << monkeyNode->monkey.getServiceCountry() << ", Reserved: " << monkeyNode->monkey.getReserved() << endl;
        inOrder(monkeyNode->right);
    }
}




//Create dog objects from file data
static void loadDogs(string file, DogBST* dogbst) {
    ifstream inFS;
    string line = "";
    try {//attempt to open file and parse data
        inFS.open(file);
        while (getline(inFS, line)) {
            string name;
            string breed;
            string gender;
            string age;
            string weight;
            string acqDate;
            string acqCountry;
            string train;
            string r;
            string serveCountry;
            Dog dog;

            stringstream inputString(line);
            getline(inputString, name, ',');
            dog.setName(name);
            getline(inputString, breed, ',');
            dog.setBreed(breed);
            getline(inputString, gender, ',');
            dog.setGender(gender);
            getline(inputString, age, ',');
            dog.setAge(age);
            getline(inputString, weight, ',');
            dog.setWeight(weight);
            getline(inputString, acqDate, ',');
            dog.setAcquisitionDate(acqDate);
            getline(inputString, acqCountry, ',');
            dog.setAcquisitionCountry(acqCountry);
            getline(inputString, train, ',');
            dog.setTrainingStatus(train);
            getline(inputString, r, ',');
            bool reserved = (r == "true");
            dog.setReserved(reserved);
            getline(inputString, serveCountry);
            dog.setServiceCountry(serveCountry);
            

            dogbst->Insert(dog);
        }
        inFS.close();
    }
    catch (runtime_error& excpt) {
        cerr << "There has been an error" << endl;
    }
}

//Create monkey objects from file data
static void loadMonkeys(string file, MonkeyBST* monkeybst) {
    ifstream inFS;
    string line = "";
    try {//attempt to open file and parse data
        inFS.open(file);
        while (getline(inFS, line)) {
            string name;
            string species;
            string gender;
            string age;
            string weight;
            string tail;
            string height;
            string body;
            string acqDate;
            string acqCountry;
            string train;
            string r;
            string serveCountry;
            Monkey monkey;

            stringstream inputString(line);
            getline(inputString, name, ',');
            monkey.setName(name);
            getline(inputString, species, ',');
            monkey.setSpecies(species);
            getline(inputString, gender, ',');
            monkey.setGender(gender);
            getline(inputString, age, ',');
            monkey.setAge(age);
            getline(inputString, weight, ',');
            monkey.setWeight(weight);
            getline(inputString, tail, ',');
            monkey.setTailLength(tail);
            getline(inputString, height, ',');
            monkey.setHeight(height);
            getline(inputString, body, ',');
            monkey.setBodyLength(body);
            getline(inputString, acqDate, ',');
            monkey.setAcquisitionDate(acqDate);
            getline(inputString, acqCountry, ',');
            monkey.setAcquisitionCountry(acqCountry);
            getline(inputString, train, ',');
            monkey.setTrainingStatus(train);
            getline(inputString, r, ',');
            bool reserved = (r == "true");
            monkey.setReserved(reserved);
            getline(inputString, serveCountry);
            monkey.setServiceCountry(serveCountry);


            monkeybst->Insert(monkey);
        }
        inFS.close();
    }
    catch (runtime_error& excpt) {
        cerr << "There has been an error" << endl;
    }
}

//Driver
int main()
{
    DogBST* dogbst;
    dogbst = new DogBST();
    MonkeyBST* monkeybst;
    monkeybst = new MonkeyBST();
    char option;
    string file1 = "DogFile.csv";
    loadDogs(file1, dogbst);
    string file2 = "MonkeyFile.csv";
    loadMonkeys(file2, monkeybst);
    
    cout << "Welcome to Grazioso Search and Rescue System!" << endl;
    do {
        displayMenu();
        cin >> option;
        switch (option) {
        case '1':
            //Intake a new dog
            intakeNewDog(dogList);
            break;
        case '2':
            //Intake a new monkey
            intakeNewMonkey(monkeyList);
            break;
        case '3':
            //Reserve an animal of user choice
            reserveAnimal(dogList, monkeyList);
            break;
        case '4':
            //Print All Dogs in List
            dogbst->InOrder();
            break;
        case '5':
            //Print All Monkeys in List
            monkeybst->InOrder();

            break;
        case '6':
            //All avaliable animals
            availableAnimals(dogList, monkeyList);
            break;
        case 'q':
            cout << "goodbye!";
            break;
        default:
            cout << "Invalid input" << endl;
        }
    } while (option != 'q');

    return 0;
}