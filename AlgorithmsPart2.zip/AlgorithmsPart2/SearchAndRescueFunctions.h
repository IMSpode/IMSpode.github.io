//#ifndef SEARCHANDRESCUEFUNCTION_H
//#define SEARCHANDRESCUEFUNCTION_H
#pragma once
#include <vector>

#include "Dog.h"
#include "Monkey.h"

void displayMenu();

void printAllDogs(vector<Dog>);

void printAllMonkeys(vector<Monkey>);

void intakeNewDog(vector<Dog>&);

void intakeNewMonkey(vector<Monkey>&);

void reserveAnimal(vector<Dog>&, vector<Monkey>&);

void reserveDog(vector<Dog>&);

void reserveMonkey(vector<Monkey>&);

void availableAnimals(vector<Dog>&, vector<Monkey>&);

void printGenders();

void printCountries();

void printStatus();

void printReserved();

void printSpecies();


//#endif
