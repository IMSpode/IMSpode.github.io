#ifndef DOG_H
#define DOG_H
#pragma once
#include "RescueAnimal.h"
class Dog :
    public RescueAnimal
{
private:
    string breed;
public:
    Dog();
    //constructor
    Dog(string name, string breed, string gender, string age,
        string weight, string acquisitionDate, string acquisitionCountry,
        string trainingStatus, bool reserved, string serviceCountry);

    //getter
    string getBreed();

    //setter
    void setBreed(string breed);

};

#endif

