#ifndef MONKEY_H
#define MONKEY_H
#pragma once
#include "RescueAnimal.h"
class Monkey :
    public RescueAnimal
{
private:
    double tailLength;
    double height;
    double bodyLength;
    string species;
public:
    //constructor
    Monkey(string name, string species, string gender, int age, double weight, 
        double tailLength, double height, double bodyLength, string acquisitionDate, 
        string acquisitionCountry, string trainingStatus, bool reserved, 
        string serviceCountry);

    //getter
    double getTailLength();
    double getHeight();
    double getBodyLength();
    string getSpecies();

    //setter
    void setTailLength(double tailLength);
    void setHeight(double height);
    void setBodyLength(double bodyLength);
    void setSpecies(string species);
};

#endif

