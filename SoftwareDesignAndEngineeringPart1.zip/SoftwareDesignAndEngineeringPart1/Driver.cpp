//Blake Allen 2026
// Driver.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
#include "Dog.h"
#include "Monkey.h"
#include "SearchAndRescueFunctions.h"

//creates vectors to hold dogs and monkeys
vector<Dog> dogList;
vector<Monkey> monkeyList;






//Populates a list of dogs
static void initializeDogList() {
    Dog dog1 = Dog("spot", "german shepherd", "male", 1, 91.5, "05-12-2019", "united states", "intake", false, "united states");
    Dog dog2 = Dog("rex", "great dane", "male", 3, 110.1, "02-03-2020", "united states", "phase i", false, "united states");
    Dog dog3 = Dog("bella", "chihuahua", "female", 4, 4.9, "12-12-2019", "canada", "in service", true, "canada");
    Dog dog4 = Dog("max", "corgi", "male", 2, 25.3, "08-20-2021", "mexico", "in service", false, "mexico");

    dogList.push_back(dog1);
    dogList.push_back(dog2);
    dogList.push_back(dog3);
    dogList.push_back(dog4);
    
}


//Populates a list of monkeys
static void initializeMonkeyList() {
    Monkey monkey1 = Monkey("manny", "capuchin", "male", 2, 12.2, 10, 12.3, 5.3, "09-12-2023", "canada", "in service", false, "united states");
    Monkey monkey2 = Monkey("benny", "guenon", "male", 2, 12.2, 10, 12.3, 5.3, "09-13-2023", "mexico", "intake", false, "mexico");
    Monkey monkey3 = Monkey("sally", "squirrel monkey", "female", 2, 12.2, 10, 12.3, 5.3, "09-12-2023", "canada", "in service", true, "united states");
    Monkey monkey4 = Monkey("sue", "tamarin", "female", 2, 12.2, 10, 12.3, 5.3, "09-14-2023", "united states", "phase ii", false, "mexico");

    monkeyList.push_back(monkey1);
    monkeyList.push_back(monkey2);
    monkeyList.push_back(monkey3);
    monkeyList.push_back(monkey4);
}



//Driver
int main()
{
    char option;
    initializeDogList();
    initializeMonkeyList();
    cout << "**********************************************" << endl;
    cout << "Welcome to Grazioso Search and Rescue System!" << endl;
    do {
        displayMenu();
        cin >> option;
        switch (option) {
        case '1':
            //Intake a new dog
            intakeNewDog(dogList);
            break;
        case '2':
            //Intake a new monkey
            intakeNewMonkey(monkeyList);
            break;
        case '3':
            //Reserve an animal of user choice
            reserveAnimal(dogList, monkeyList);
            break;
        case '4':
            //Print All Dogs in List
            printAllDogs(dogList);
            
            break;
        case '5':
            //Print All Monkeys in List
            printAllMonkeys(monkeyList);
            
            break;
        case '6':
            //All avaliable animals
            availableAnimals(dogList, monkeyList);
            break;
        case 'q':
            cout << "goodbye!";
            break;
        default:
            cout << "Invalid input" << endl;
        }
    } while (option != 'q');

    return 0;
}


