#ifndef RESCUEANIMAL_H
#define RESCUEANIMAL_H
#pragma once
#include <string>

using namespace std;


class RescueAnimal
{
private:
	string name;
	string gender;
	int age;
	double weight;
	string acquisitionDate;
	string acquisitionCountry;
	string trainingStatus;
	bool reserved;
	string serviceCountry;

public:
	//getters
	string getName();
	string getGender();
	int getAge();
	double getWeight();
	string getAcquisitionDate();
	string getAcquisitionCountry();
	string getTrainingStatus();
	bool getReserved();
	string getServiceCountry();

	//setters
	void setName(string name);
	void setGender(string gender);
	void setAge(int age);
	void setWeight(double weight);
	void setAcquisitionDate(string date);
	void setAcquisitionCountry(string country);
	void setTrainingStatus(string status);
	void setReserved(bool reserve);
	void setServiceCountry(string country);
};
#endif

