#include "Dog.h"


//constructor
Dog::Dog(string name, string breed, string gender, int age, 
	double weight, string acquisitionDate, string acquisitionCountry, 
	string trainingStatus, bool reserved, string serviceCountry){
	setName(name);
	setBreed(breed);
	setGender(gender);
	setAge(age);
	setWeight(weight);
	setAcquisitionDate(acquisitionDate);
	setAcquisitionCountry(acquisitionCountry);
	setTrainingStatus(trainingStatus);
	setReserved(reserved);
	setServiceCountry(serviceCountry);
}
//getter
string Dog::getBreed() {
	return breed;
}

//setter
void Dog::setBreed(string breed){
	this->breed = breed;
}
