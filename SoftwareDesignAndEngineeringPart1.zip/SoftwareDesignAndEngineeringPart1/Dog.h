#ifndef DOG_H
#define DOG_H
#pragma once
#include "RescueAnimal.h"
class Dog :
    public RescueAnimal
{
private:
    string breed;
public:
    //constructor
    Dog(string name, string breed, string gender, int age,
        double weight, string acquisitionDate, string acquisitionCountry,
        string trainingStatus, bool reserved, string serviceCountry);

    //getter
    string getBreed();

    //setter
    void setBreed(string breed);

};

#endif

