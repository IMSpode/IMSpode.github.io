#include "SearchAndRescueFunctions.h"

#include <iostream>
#include <vector>
#include <algorithm>


using namespace std;

//prints main menu options
void displayMenu() {
    cout <<  "**********************************************" << endl;
    cout << "Menu:" << endl;
    cout << "**********************************************" << endl;
    cout << endl;
    cout << "[1] Intake new Dog" << endl;
    cout << "[2] Intake new Monkey" << endl;
    cout << "[3] Reserve an Animal" << endl;
    cout << "[4] Print a list of all Dogs" << endl;
    cout << "[5] Print a list of all Monkeys" << endl;
    cout << "[6] List all avaliable Animals" << endl;
    cout << "[q] Quit application" << endl;
    cout << "Select an option: ";
}

//prints options of male or female
void printGenders() {
    cout << "What is the animals gender?" << endl;
    cout << "[m] male" << endl;
    cout << "[f] female" << endl;
}

//prints available countries
void printCountries() {
    cout << "[1] United States" << endl;
    cout << "[2] Canada" << endl;
    cout << "[3] Mexico" << endl;
}

//displays training status options
void printStatus() {
    cout << "Training Status?" << endl;
    cout << "[1] Intake" << endl;
    cout << "[2] Phase I" << endl;
    cout << "[3] Phase II" << endl;
    cout << "[4] In Service" << endl;
}

//prints option of available or reserved
void printReserved() {
    cout << "Is the animal reserved?" << endl;
    cout << "[1] Avaiable" << endl;
    cout << "[2] Reserved" << endl;
}

//displays available monkey species
void printSpecies() {
    cout << "Select the allowed monkey's species: " << endl;
    cout << "[1] Capuchin" << endl;
    cout << "[2] Guenon" << endl;
    cout << "[3] Macaque" << endl;
    cout << "[4] Marmoset" << endl;
    cout << "[5] Squirrel Monkey" << endl;
    cout << "[6] Tamarin" << endl;
}

//prints all dogs currently in the dogList
void printAllDogs(vector<Dog> dogList) {
    cout << "All Dogs" << endl;
    for (Dog& dog : dogList) {
        cout << dog.getName() << ", " << dog.getTrainingStatus() << ", " << dog.getServiceCountry() << ", Reserved: " << dog.getReserved() << endl;
    }
}

//prints all monkeys currently in the monkeyList
void printAllMonkeys(vector<Monkey> monkeyList) {
    cout << "All Monkeys" << endl;
    for (Monkey& monkey : monkeyList) {
        cout << monkey.getName() << ", " << monkey.getTrainingStatus() << ", " << monkey.getServiceCountry() << ", Reserved: " << monkey.getReserved() << endl;
    }
}

//Function to intake new dog and add to dogList
void intakeNewDog(vector<Dog>& dogList) {
    string tempString;
    char tempChar;
    int tempInt;
    double tempDouble;

    //check if dog is already in system
    cout << "What is the dog's name? ";
    cin >> tempString;
    transform(tempString.begin(), tempString.end(), tempString.begin(), ::tolower);
    cout << endl;
    for (Dog dog : dogList) {
        if (dog.getName() == tempString) {
            cout << "This dog is already in the system." << endl;
            return;
        }
    }
    //initialize new dog to list
    Dog dog = Dog(tempString, "", "", 0, 0.0, "", "", "", false, "");

    //dog breed
    cout << "What is the dog's breed? ";
    cin >> tempString;
    cout << endl;
    dog.setBreed(tempString);

    //dog gender
    printGenders();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case 'm':
            dog.setGender("male");
            break;
        case 'f':
            dog.setGender("female");
            break;
        default:
            cout << "Select male [m] or female [f].";
        }
    } while (tempChar != 'f' && tempChar != 'm');

    //dog age
    cout << "How old is the dog? ";
    cin >> tempInt;
    cout << endl;
    dog.setAge(tempInt);

    //dog weight
    cout << "How much does the dog weight? ";
    cin >> tempDouble;
    cout << endl;
    dog.setWeight(tempDouble);

    //Aquired date
    cout << "Date aquired? mm-dd-yyyy " << endl;
    cin >> tempString;
    cout << endl;
    dog.setAcquisitionDate(tempString);

    //Aquired country
    cout << "Aquired Country? Pick One: " << endl;
    printCountries();

    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            dog.setAcquisitionCountry("united states");
            break;
        case '2':
            dog.setAcquisitionCountry("canada");
            break;
        case '3':
            dog.setAcquisitionCountry("mexico");
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    //training status
    printStatus();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            dog.setTrainingStatus("intake");
            break;
        case '2':
            dog.setTrainingStatus("phase i");
            break;
        case '3':
            dog.setTrainingStatus("phase ii");
            break;
        case '4':
            dog.setTrainingStatus("in service");
            break;
        default:
            cout << "Please select a valid status." << endl;
        }
    } while (tempChar != '1' && tempChar != '2' && tempChar != '3' && tempChar != '4');

    //service country
    cout << "What country does the dog serve? " << endl;
    printCountries();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            dog.setServiceCountry("united states");
            break;
        case '2':
            dog.setServiceCountry("canada");
            break;
        case '3':
            dog.setServiceCountry("mexico");
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    //Is the dog avaiable?
    printReserved();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            dog.setReserved(false);
            break;
        case '2':
            dog.setReserved(true);
            break;
        default:
            cout << "Select avaliable [1] or reserved [2].";
        }
    } while (tempChar != '1' && tempChar != '2');

    dogList.push_back(dog);
}

//Function to intake new monkey and add to monkeyList
void intakeNewMonkey(vector<Monkey>& monkeyList) {
    string tempString;
    char tempChar;
    int tempInt;
    double tempDouble;

    //check if monkey is already in system
    cout << "What is the monkey's name? ";
    cin >> tempString;
    transform(tempString.begin(), tempString.end(), tempString.begin(), ::tolower);
    cout << endl;
    for (Monkey monkey : monkeyList) {
        if (monkey.getName() == tempString) {
            cout << "This monkey is already in the system." << endl;
            return;
        }
    }
    //initialize new monkey to list
    Monkey monkey = Monkey(tempString, "", "", 0, 0.0, 0.0, 0.0, 0.0, "", "", "", false, "");

    //check if monkey species is allowed
    printSpecies();
    cin >> tempChar;
    switch (tempChar) {
    case '1':
        monkey.setSpecies("capuchin");
        break;
    case '2':
        monkey.setSpecies("guenon");
        break;
    case '3':
        monkey.setSpecies("macaque");
        break;
    case '4':
        monkey.setSpecies("marmoset");
        break;
    case '5':
        monkey.setSpecies("squirrel monkey");
        break;
    case '6':
        monkey.setSpecies("tamarin");
        break;
    default:
        cout << "That species is not allowed." << endl;
        return;
    }

    //monkey gender
    printGenders();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case 'm':
            monkey.setGender("male");
            break;
        case 'f':
            monkey.setGender("female");
            break;
        default:
            cout << "Select male [m] or female [f].";
        }
    } while (tempChar != 'f' && tempChar != 'm');

    //monkey age
    cout << "How old is the monkey? ";
    cin >> tempInt;
    cout << endl;
    monkey.setAge(tempInt);

    //monkey weight
    cout << "How much does the monkey weight? ";
    cin >> tempDouble;
    cout << endl;
    monkey.setWeight(tempDouble);

    //Tail length
    cout << "How long is the monkey's tail? ";
    cin >> tempDouble;
    monkey.setTailLength(tempDouble);

    //Height
    cout << "How tall is the monkey? ";
    cin >> tempDouble;
    monkey.setHeight(tempDouble);

    //Body length
    cout << "How long is the monkey's body? ";
    cin >> tempDouble;
    monkey.setBodyLength(tempDouble);

    //Aquired date
    cout << "Date aquired? mm-dd-yyyy " << endl;
    cin >> tempString;
    cout << endl;
    monkey.setAcquisitionDate(tempString);

    //Aquired country
    cout << "Aquired Country? Pick One: " << endl;
    printCountries();

    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            monkey.setAcquisitionCountry("united states");
            break;
        case '2':
            monkey.setAcquisitionCountry("canada");
            break;
        case '3':
            monkey.setAcquisitionCountry("mexico");
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    //training status
    printStatus();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            monkey.setTrainingStatus("intake");
            break;
        case '2':
            monkey.setTrainingStatus("phase i");
            break;
        case '3':
            monkey.setTrainingStatus("phase ii");
            break;
        case '4':
            monkey.setTrainingStatus("in service");
            break;
        default:
            cout << "Please select a valid status." << endl;
        }
    } while (tempChar != '1' && tempChar != '2' && tempChar != '3' && tempChar != '4');

    //service country
    cout << "What country does the monkey serve? " << endl;
    printCountries();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            monkey.setServiceCountry("united states");
            break;
        case '2':
            monkey.setServiceCountry("canada");
            break;
        case '3':
            monkey.setServiceCountry("mexico");
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    //Is the monkey avaiable?
    printReserved();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            monkey.setReserved(false);
            break;
        case '2':
            monkey.setReserved(true);
            break;
        default:
            cout << "Select avaliable [1] or reserved [2].";
        }
    } while (tempChar != '1' && tempChar != '2');

    monkeyList.push_back(monkey);
}

//Reserve animal function, used to call reserveDog or reserveMonkey
void reserveAnimal(vector<Dog>& dogList, vector<Monkey>& monkeyList) {
    string animal;

    do {
        cout << "What is your desired animal type? (dog or monkey)" << endl;
        cin >> animal;
        transform(animal.begin(), animal.end(), animal.begin(), ::tolower);
        if (animal == "dog") {
            reserveDog(dogList);
        }
        else if (animal == "monkey") {
            reserveMonkey(monkeyList);
        }
        else {
            cout << "Rescue Service only has dogs and monkeys." << endl;
        }
    } while (animal != "dog" && animal != "monkey");
}

//Reserve a Dog
void reserveDog(vector<Dog>& dogList) {
    char charCountry;
    string stringCountry;
    cout << "What country do you require service is? " << endl;
    printCountries();
    do {
        cin >> charCountry;
        switch (charCountry) {
        case '1':
            stringCountry = "united states";
            break;
        case '2':
            stringCountry = "canada";
            break;
        case '3':
            stringCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (charCountry != '1' && charCountry != '2' && charCountry != '3');
    for (Dog& dog : dogList) {
        if (dog.getServiceCountry() == stringCountry && dog.getReserved() == false && dog.getTrainingStatus() == "in service") {
            cout << "The dog " << dog.getName() << " has been reserved for you." << endl;
            dog.setReserved(true);
            return;
        }
    }
    cout << "No dogs are available for that location." << endl;
}

//Reserve a monkey
void reserveMonkey(vector<Monkey>& monkeyList) {
    char charCountry;
    string stringCountry;
    cout << "What country do you require service is? " << endl;
    printCountries();
    do {
        cin >> charCountry;
        switch (charCountry) {
        case '1':
            stringCountry = "united states";
            break;
        case '2':
            stringCountry = "canada";
            break;
        case '3':
            stringCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (charCountry != '1' && charCountry != '2' && charCountry != '3');
    for (Monkey& monkey : monkeyList) {
        if (monkey.getServiceCountry() == stringCountry && monkey.getReserved() == false && monkey.getTrainingStatus() == "in service") {
            cout << "The monkey " << monkey.getName() << " has been reserved for you." << endl;
            monkey.setReserved(true);
            return;
        }

    }
    cout << "No monkeys are avaliable for that location." << endl;
}

//Print all available animals
void availableAnimals(vector<Dog>& dogList, vector<Monkey>& monkeyList) {
    cout << "Available dogs: " << endl;
    for (Dog& dog : dogList) {
        if (dog.getReserved() == false && dog.getTrainingStatus() == "in service") {
            cout << dog.getName() << ", " << dog.getBreed() << ", " << dog.getServiceCountry() << endl;
        }
    }
    cout << "Available monkeys: " << endl;
    for (Monkey& monkey : monkeyList) {
        if (monkey.getReserved() == false && monkey.getTrainingStatus() == "in service") {
            cout << monkey.getName() << ", " << monkey.getSpecies() << ", " << monkey.getServiceCountry() << endl;
        }
    }
}