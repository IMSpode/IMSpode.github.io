#include "Monkey.h"

//constructor
Monkey::Monkey(string name, string species, string gender, 
	int age, double weight, double tailLength, double height, 
	double bodyLength, string acquisitionDate, 
	string acquisitionCountry, string trainingStatus, 
	bool reserve, string serviceCountry){
	setName(name);
	setSpecies(species);
	setGender(gender);
	setAge(age);
	setWeight(weight);
	setTailLength(tailLength);
	setHeight(height);
	setBodyLength(bodyLength);
	setAcquisitionDate(acquisitionDate);
	setAcquisitionCountry(acquisitionCountry);
	setTrainingStatus(trainingStatus);
	setReserved(reserve);
	setServiceCountry(serviceCountry);
}

//getter
double Monkey::getTailLength(){
	return tailLength;
}
double Monkey::getHeight(){
	return height;
}
double Monkey::getBodyLength(){
	return bodyLength;
}
string Monkey::getSpecies(){
	return species;
}

//setter
void Monkey::setTailLength(double tailLength){
	this->tailLength = tailLength;
}
void Monkey::setHeight(double height){
	this->height = height;
}
void Monkey::setBodyLength(double bodyLength){
	this->bodyLength = bodyLength;
}
void Monkey::setSpecies(string species){
	this->species = species;
}

