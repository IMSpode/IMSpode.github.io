//#ifndef SEARCHANDRESCUEFUNCTION_H
//#define SEARCHANDRESCUEFUNCTION_H
#pragma once




void displayMenu();

void printGenders();

void printCountries();

void printStatus();

void printReserved();

void printSpecies();


//#endif
