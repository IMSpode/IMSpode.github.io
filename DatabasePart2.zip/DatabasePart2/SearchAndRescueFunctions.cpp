#include "SearchAndRescueFunctions.h"

#include <iostream>



using namespace std;

void displayMenu() {
    cout << "Menu:" << endl;
    cout << endl;
    cout << "[1] Intake new Dog" << endl;
    cout << "[2] Intake new Monkey" << endl;
    cout << "[3] Reserve an Animal" << endl;
    cout << "[4] Print a list of all Dogs" << endl;
    cout << "[5] Print a list of all Monkeys" << endl;
    cout << "[6] List all avaliable Animals" << endl;
    cout << "[q] Quit application" << endl;
    cout << "Select an option: ";
}

void printGenders() {
    cout << "What is the animals gender?" << endl;
    cout << "[m] male" << endl;
    cout << "[f] female" << endl;
}

void printCountries() {
    cout << "[1] United States" << endl;
    cout << "[2] Canada" << endl;
    cout << "[3] Mexico" << endl;
}

void printStatus() {
    cout << "Training Status?" << endl;
    cout << "[1] Intake" << endl;
    cout << "[2] Phase I" << endl;
    cout << "[3] Phase II" << endl;
    cout << "[4] In Service" << endl;
}

void printReserved() {
    cout << "Is the animal reserved?" << endl;
    cout << "[1] Avaiable" << endl;
    cout << "[2] Reserved" << endl;
}

void printSpecies() {
    cout << "Select the allowed monkey's species: " << endl;
    cout << "[1] Capuchin" << endl;
    cout << "[2] Guenon" << endl;
    cout << "[3] Macaque" << endl;
    cout << "[4] Marmoset" << endl;
    cout << "[5] Squirrel Monkey" << endl;
    cout << "[6] Tamarin" << endl;
}



