//Blake Allen 2026
// Driver.cpp : This file contains the 'main' function. Program execution begins and ends there.
//



#include <iostream>
#include <string>
#include <algorithm>

#include <boost/url/url.hpp>
//#include <boost/url/param.hpp>

//mongoDB libraries
#include <mongocxx/instance.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/collection.hpp>
#include <mongocxx/uri.hpp>
#include <mongocxx/exception/exception.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/document/element.hpp>
#include <bsoncxx/document/view.hpp>



using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_document;
using namespace std;

#include "SearchAndRescueFunctions.h"



//find and update dog availability
static void updateDog(mongocxx::collection& c_Dogs) {
    cout << "UPDATING DOG FUNCTION" << endl;
    char charCountry;
    string stringCountry;
    cout << "What country do you require service is? " << endl;
    printCountries();
    do {
        cin >> charCountry;
        switch (charCountry) {
        case '1':
            stringCountry = "united states";
            break;
        case '2':
            stringCountry = "canada";
            break;
        case '3':
            stringCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (charCountry != '1' && charCountry != '2' && charCountry != '3');
    auto doc = c_Dogs.find_one(
        make_document(kvp("$and",
            bsoncxx::builder::basic::make_array(make_document(kvp("tStatus", "in service")),
                make_document(kvp("reserved", false)), make_document(kvp("serviceCountry", stringCountry))))));
    auto docValue = *doc;
    if (doc) {
        cout << "Dog match found and reserved: " << endl;
        cout << docValue["name"].get_string().value << " has been reserved for you!" << endl;
    }
    else {
        cout << "No available dogs" << endl;
        return;
    }
    auto query_filter = make_document(kvp("$and",
        bsoncxx::builder::basic::make_array(make_document(kvp("tStatus", "in service")),
            make_document(kvp("reserved", false)), make_document(kvp("serviceCountry", stringCountry)))));
    auto update_doc = make_document(kvp("$set", make_document(kvp("reserved", true))));
    auto result = c_Dogs.update_one(query_filter.view(), update_doc.view());
}

//find and update monkey availability
static void updateMonkey(mongocxx::collection& c_Monkeys) {
    cout << "UPDATING MONEKY FUNCTION" << endl;
    char charCountry;
    string stringCountry;
    cout << "What country do you require service is? " << endl;
    printCountries();
    do {
        cin >> charCountry;
        switch (charCountry) {
        case '1':
            stringCountry = "united states";
            break;
        case '2':
            stringCountry = "canada";
            break;
        case '3':
            stringCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (charCountry != '1' && charCountry != '2' && charCountry != '3');
    auto doc = c_Monkeys.find_one(
        make_document(kvp("$and",
            bsoncxx::builder::basic::make_array(make_document(kvp("tStatus", "in service")),
                make_document(kvp("reserved", false)), make_document(kvp("serviceCountry", stringCountry))))));
    auto docValue = *doc;
    if (doc) {
        cout << "Monkey match found and reserved: " << endl;
        cout << docValue["name"].get_string().value << " has been reserved for you!" << endl;
    }
    else {
        cout << "No available monkeys" << endl;
        return;
    }
    auto query_filter = make_document(kvp("$and",
        bsoncxx::builder::basic::make_array(make_document(kvp("tStatus", "in service")),
            make_document(kvp("reserved", false)), make_document(kvp("serviceCountry", stringCountry)))));
    auto update_doc = make_document(kvp("$set", make_document(kvp("reserved", true))));
    auto result = c_Monkeys.update_one(query_filter.view(), update_doc.view());
}

//Reserve animal type
static void updateAnimal(mongocxx::collection& c_Dogs, mongocxx::collection& c_Monkeys) {
    string animal;

    do {
        cout << "What is your desired animal type? (dog or monkey)" << endl;
        cin >> animal;
        transform(animal.begin(), animal.end(), animal.begin(), ::tolower);
        if (animal == "dog") {
            updateDog(c_Dogs);
        }
        else if (animal == "monkey") {
            updateMonkey(c_Monkeys);
        }
        else {
            cout << "Rescue Service only has dogs and monkeys." << endl;
        }
    } while (animal != "dog" && animal != "monkey");
}

//create new dog
static void createDog(mongocxx::collection c_Dogs) {
    string name;
    string breed;
    string gender;
    int age;
    double weight;
    string acqDate;
    string acqCountry;
    string status;
    string serveCountry;
    bool reserved;
    char tempChar;

    cout << "What is the dog's name? ";
    cin >> name;

    cout << "What is the dog's breed? ";
    cin >> breed;//NOTE: currently only records first word

    printGenders();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case 'm':
            gender = "male";
            break;
        case 'f':
            gender = "female";
            break;
        default:
            cout << "Select male [m] or female [f].";
        }
    } while (tempChar != 'f' && tempChar != 'm');

    cout << "How old is the dog> ";
    cin >> age;

    cout << "How much does the dog weight? ";
    cin >> weight;

    cout << "Date acquired? mm-dd-yyyy : ";
    cin >> acqDate;

    cout << "Acquired Country? Pick One: " << endl;
    printCountries();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            acqCountry = "united states";
            break;
        case '2':
            acqCountry = "canada";
            break;
        case '3':
            acqCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    printStatus();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            status = "intake";
            break;
        case '2':
            status = "phase i";
            break;
        case '3':
            status = "phase ii";
            break;
        case '4':
            status = "in service";
            break;
        default:
            cout << "Please select a valid status." << endl;
        }
    } while (tempChar != '1' && tempChar != '2' && tempChar != '3' && tempChar != '4');

    cout << "What country does the dog serve? " << endl;
    printCountries();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            serveCountry = "united states";
            break;
        case '2':
            serveCountry = "canada";
            break;
        case '3':
            serveCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    printReserved();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            reserved = false;
            break;
        case '2':
            reserved = true;
            break;
        default:
            cout << "Select avaliable [1] or reserved [2].";
        }
    } while (tempChar != '1' && tempChar != '2');

    auto dog = make_document(
        kvp("name", name),
        kvp("breed", breed),
        kvp("gender", gender),
        kvp("age", age),
        kvp("weight", weight),
        kvp("AcqDate", acqDate),
        kvp("AcqCountry", acqCountry),
        kvp("tStatus", status),
        kvp("reserved", reserved),
        kvp("serviceCountry", serveCountry)
        );
    c_Dogs.insert_one(dog.view());
}

//create new monkey
static void createMonkey(mongocxx::collection c_Monkeys) {
    string name;
    string species;
    string gender;
    int age;
    double weight;
    double tail;
    double height;
    double body;
    string acqDate;
    string acqCountry;
    string status;
    bool reserved;
    string serveCountry;
    char tempChar;

    cout << "What is the monkey's name? ";
    cin >> name;

    printSpecies();
    cin >> tempChar;
    switch (tempChar) {
    case '1':
        species = "capuchin";
        break;
    case '2':
        species = "guenon";
        break;
    case '3':
        species = "macaque";
        break;
    case '4':
        species = "marmoset";
        break;
    case '5':
        species = "squirrel monkey";
        break;
    case '6':
        species = "tamarin";
        break;
    default:
        cout << "That species is not allowed." << endl;
        return;
    }

    printGenders();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case 'm':
            gender = "male";
            break;
        case 'f':
            gender = "female";
            break;
        default:
            cout << "Select male [m] or female [f].";
        }
    } while (tempChar != 'f' && tempChar != 'm');

    cout << "How old is the monkey? ";
    cin >> age;

    cout << "How much does the monkey weigh? ";
    cin >> weight;

    cout << "How long is the monkey's tail? ";
    cin >> tail;

    cout << "How tall is the monkey? ";
    cin >> height;

    cout << "How long is the monkey's body? ";
    cin >> body;

    cout << "Date acquired? mm-dd-yyyy: ";
    cin >> acqDate;

    cout << "Acquired Country? Pick one: " << endl;
    printCountries();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            acqCountry = "united states";
            break;
        case '2':
            acqCountry = "canada";
            break;
        case '3':
            acqCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    printStatus();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            status = "intake";
            break;
        case '2':
            status = "phase i";
            break;
        case '3':
            status = "phase ii";
            break;
        case '4':
            status = "in service";
            break;
        default:
            cout << "Please select a valid status." << endl;
        }
    } while (tempChar != '1' && tempChar != '2' && tempChar != '3' && tempChar != '4');

    cout << "What country does the monkey serve? " << endl;
    printCountries();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            serveCountry = "united states";
            break;
        case '2':
            serveCountry = "canada";
            break;
        case '3':
            serveCountry = "mexico";
            break;
        default:
            cout << "Please select a valid country." << endl;
        }

    } while (tempChar != '1' && tempChar != '2' && tempChar != '3');

    printReserved();
    do {
        cin >> tempChar;
        switch (tempChar) {
        case '1':
            reserved = false;
            break;
        case '2':
            reserved = true;
            break;
        default:
            cout << "Select avaliable [1] or reserved [2].";
        }
    } while (tempChar != '1' && tempChar != '2');

    auto monkey = make_document(
        kvp("name", name),
        kvp("species", species),
        kvp("gender", gender),
        kvp("age", age),
        kvp("weight", weight),
        kvp("tailLenght", tail),
        kvp("height", height),
        kvp("bodyLength", body),
        kvp("AcqDate", acqDate),
        kvp("AcqCountry", acqCountry),
        kvp("tStatus", status),
        kvp("reserved", reserved),
        kvp("serviceCountry", serveCountry)
    );
    c_Monkeys.insert_one(monkey.view());
}

//read and print all dogs
static void printDogCollection(mongocxx::collection c_Dogs) {
    mongocxx::options::find opts;
    opts.projection(make_document(kvp("name", 1), kvp("tStatus", 1), kvp("serviceCountry", 1), kvp("reserved", 1)));

    auto cursor = c_Dogs.find({}, opts);

    for (auto&& doc : cursor) {
        if (doc["name"]) {
            cout << doc["name"].get_string().value << ", " << doc["tStatus"].get_string().value << ", "
                << doc["serviceCountry"].get_string().value << ", Reserved: ";
            if (doc["reserved"].get_bool() == 0) {
                cout << "false" << endl;
            }
            else {
                cout << "true" << endl;
            }
        }
    }
}

//read and print all monkeys
static void printMonkeyCollection(mongocxx::collection c_Monkeys) {
    mongocxx::options::find opts;
    opts.projection(make_document(kvp("name", 1), kvp("tStatus", 1), kvp("serviceCountry", 1), kvp("reserved", 1)));

    auto cursor = c_Monkeys.find({}, opts);

    for (auto&& doc : cursor) {
        if (doc["name"]) {
            cout << doc["name"].get_string().value << ", " << doc["tStatus"].get_string().value << ", "
                << doc["serviceCountry"].get_string().value << ", Reserved: ";
            if (doc["reserved"].get_bool() == 0) {
                cout << "false" << endl;
            }
            else {
                cout << "true" << endl;
            }
        }
    }
}

//find and print all available dogs and monkeys
static void printAllAvailableAnimals(mongocxx::collection c_Dogs, mongocxx::collection c_Monkeys) {
    mongocxx::options::find opts;
    opts.projection(make_document(kvp("name", 1), kvp("breed", 1), kvp("species", 1), kvp("serviceCountry", 1)));

    auto cursor1 = c_Dogs.find(
        make_document(kvp("$and",
            bsoncxx::builder::basic::make_array(make_document(kvp("tStatus", "in service")),
                make_document(kvp("reserved", false))))), opts);
    cout << "Available Dogs: " << endl;
    for (auto&& doc : cursor1) {
        cout << doc["name"].get_string().value << ", " << doc["breed"].get_string().value << ", " << doc["serviceCountry"].get_string().value << endl;
    }
    cout << endl;
   auto cursor2 = c_Monkeys.find(
        make_document(kvp("$and",
            bsoncxx::builder::basic::make_array(make_document(kvp("tStatus", "in service")),
                make_document(kvp("reserved", false))))), opts);
    cout << "Available Monkeys: " << endl;
    for (auto&& doc : cursor2) {
        cout << doc["name"].get_string().value << ", " << doc["species"].get_string().value << ", " << doc["serviceCountry"].get_string().value << endl;
    }
}











//Driver
int main()
{
    string username;
    string password;
    //use boost to construct uri
    boost::urls::url u;
    u.set_scheme("mongodb+srv");
    u.set_host("graziososearchandrescue.0aqwepo.mongodb.net");
    u.set_path("graziososearchandrescue");
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;
    u.set_user(username);
    u.set_password(password);
    u.set_query("appName=GraziosoSearchAndRescueBlakeAllen");


    mongocxx::instance instance;
    //Connect to MongoDB Atlas
    string connection = u.buffer();
    
    mongocxx::uri uri{ connection };
    //Create a mongocxx::client with a mongocxx::options::client object to set the stable api version
    mongocxx::options::client client_options;
    mongocxx::options::server_api server_api_options(mongocxx::options::server_api::version::k_version_1);
    client_options.server_api_opts(server_api_options);
    mongocxx::client client(uri, client_options);
    try {
        //ping server to verify that the connection works
        auto admin = client["admin"];
        auto command = make_document(kvp("ping", 1));
        auto result = admin.run_command(command.view());
        cout << bsoncxx::to_json(result) << endl;
        cout << "Pinged successfully. Connected to MongoDB Atlas!" << endl;
    }
    catch (const mongocxx::exception &e) {
        cerr << "An exception occurred: " << e.what() << endl;
        return EXIT_FAILURE;
    }
    auto db = client["Animals"];
    auto c_Dogs = db["GraziosoDogs"];
    auto c_Monkeys = db["GraziosoMonkeys"];
    

    char option;
    cout << "Welcome to Grazioso Search and Rescue System!" << endl;
    do {
        displayMenu();
        cin >> option;
        switch (option) {
        case '1':
            //Intake a new dog
            createDog(c_Dogs);
            break;
        case '2':
            //Intake a new monkey
            createMonkey(c_Monkeys);
            break;
        case '3':
            //Reserve an animal of user choice
            updateAnimal(c_Dogs, c_Monkeys);
            break;
        case '4':
            //Print All Dogs in List
            printDogCollection(c_Dogs);
            break;
        case '5':
            //Print All Monkeys in List
            printMonkeyCollection(c_Monkeys);
            break;
        case '6':
            //All avaliable animals
            printAllAvailableAnimals(c_Dogs, c_Monkeys);
            break;
        case 'q':
            cout << "goodbye!";
            break;
        default:
            cout << "Invalid input" << endl;
        }
    } while (option != 'q');

    return 0;
}